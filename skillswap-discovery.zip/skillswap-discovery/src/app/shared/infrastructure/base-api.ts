export abstract class BaseApi {}
